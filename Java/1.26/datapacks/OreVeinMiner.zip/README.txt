SIMPLE VEIN MINER - 26.1
========================

ENCHANTMENTS
Silk Touch and Fortune use Minecraft's real block loot tables and the actual
pickaxe in the player's main hand. No special setup is required.

PER-BLOCK DURABILITY (OFF BY DEFAULT, PER PLAYER)
Enable:  /trigger svm.durability set 1
Disable: /trigger svm.durability set 0

Server operators and command scripts can also use:
/function svm:durability/on
/function svm:durability/off

The block broken by the player already consumes durability normally. When this
option is enabled, each additional ore mined by the pack consumes exactly one
more durability point. Mining stops immediately if the pickaxe breaks.

SERVER SAFETY
A single activation mines at most 1,024 additional blocks to prevent accidental
server stalls from enormous player-built or modded block networks. Operators
can change it with: /scoreboard players set max_blocks svm.config <amount>
