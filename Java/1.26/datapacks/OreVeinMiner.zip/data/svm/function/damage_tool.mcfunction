execute if items entity @s weapon.mainhand minecraft:wooden_pickaxe run item modify entity @s weapon.mainhand svm:damage/wooden_pickaxe
execute if items entity @s weapon.mainhand minecraft:stone_pickaxe run item modify entity @s weapon.mainhand svm:damage/stone_pickaxe
execute if items entity @s weapon.mainhand minecraft:iron_pickaxe run item modify entity @s weapon.mainhand svm:damage/iron_pickaxe
execute if items entity @s weapon.mainhand minecraft:golden_pickaxe run item modify entity @s weapon.mainhand svm:damage/golden_pickaxe
execute if items entity @s weapon.mainhand minecraft:diamond_pickaxe run item modify entity @s weapon.mainhand svm:damage/diamond_pickaxe
execute if items entity @s weapon.mainhand minecraft:netherite_pickaxe run item modify entity @s weapon.mainhand svm:damage/netherite_pickaxe
execute if items entity @s weapon.mainhand minecraft:wooden_pickaxe[minecraft:damage=59] run function svm:break_tool
execute if items entity @s weapon.mainhand minecraft:stone_pickaxe[minecraft:damage=131] run function svm:break_tool
execute if items entity @s weapon.mainhand minecraft:iron_pickaxe[minecraft:damage=250] run function svm:break_tool
execute if items entity @s weapon.mainhand minecraft:golden_pickaxe[minecraft:damage=32] run function svm:break_tool
execute if items entity @s weapon.mainhand minecraft:diamond_pickaxe[minecraft:damage=1561] run function svm:break_tool
execute if items entity @s weapon.mainhand minecraft:netherite_pickaxe[minecraft:damage=2031] run function svm:break_tool
