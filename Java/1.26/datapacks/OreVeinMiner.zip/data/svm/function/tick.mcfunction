execute if score system_disabled svm.config matches 1 run return fail
function svm:check_tools
scoreboard players remove @a[scores={svm.cooldown=1..}] svm.cooldown 1
scoreboard players enable @a svm.durability
