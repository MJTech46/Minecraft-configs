scoreboard players set @s svm.broken 1
item replace entity @s weapon.mainhand with air
playsound minecraft:entity.item.break player @s ~ ~ ~ 1 1
