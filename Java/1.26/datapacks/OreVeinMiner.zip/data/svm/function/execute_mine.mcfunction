execute if block ~ ~ ~ air run return fail
execute if score @s svm.blocks >= max_blocks svm.config run return fail
loot spawn ~ ~ ~ mine ~ ~ ~ mainhand
setblock ~ ~ ~ air
scoreboard players add @s svm.blocks 1
execute if score @s svm.durability matches 1 run function svm:damage_tool
execute if score @s svm.broken matches 1 run return 0
function svm:mine_vein with storage svm:data temp1.current
