scoreboard players set @s svm.durability 0
tellraw @s [{"text":"[SVM] ","color":"gold"},{"text":"Per-block durability disabled.","color":"yellow"}]
