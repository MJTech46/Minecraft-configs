scoreboard players set @s svm.durability 1
tellraw @s [{"text":"[SVM] ","color":"gold"},{"text":"Per-block durability enabled.","color":"green"}]
