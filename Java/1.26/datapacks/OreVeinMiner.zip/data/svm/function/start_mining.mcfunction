$scoreboard players reset @s svm.b.$(namespace).$(id)
execute if score sneak_mode svm.config matches 1 unless predicate svm:is_sneaking run return fail
execute if entity @s[scores={svm.cooldown=1..}] run return fail
execute unless items entity @s weapon.mainhand #minecraft:pickaxes run return fail
scoreboard players set @s svm.broken 0
scoreboard players set @s svm.blocks 0
data modify storage svm:data temp1.current set from storage svm:data temp0.current
function svm:find_mining_location
