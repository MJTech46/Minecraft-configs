execute if data storage svm:data category{pickaxe:1b} run function svm:check_pickaxe
