$execute positioned ~ ~ ~1 if block ~ ~ ~ $(namespace):$(id) run function svm:execute_mine
$execute positioned ~ ~ ~-1 if block ~ ~ ~ $(namespace):$(id) run function svm:execute_mine
$execute positioned ~1 ~ ~ if block ~ ~ ~ $(namespace):$(id) run function svm:execute_mine
$execute positioned ~-1 ~ ~ if block ~ ~ ~ $(namespace):$(id) run function svm:execute_mine
$execute positioned ~ ~1 ~ if block ~ ~ ~ $(namespace):$(id) run function svm:execute_mine
$execute positioned ~ ~-1 ~ if block ~ ~ ~ $(namespace):$(id) run function svm:execute_mine
