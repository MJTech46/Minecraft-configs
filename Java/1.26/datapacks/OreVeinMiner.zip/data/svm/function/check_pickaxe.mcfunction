data modify storage svm:data temp0.list set from storage svm:data blocks.pickaxe
function svm:check_loop
