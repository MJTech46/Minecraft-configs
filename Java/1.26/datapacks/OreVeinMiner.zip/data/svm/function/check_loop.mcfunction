data modify storage svm:data temp0.current set from storage svm:data temp0.list[-1]
data remove storage svm:data temp0.list[-1]
function svm:check_block with storage svm:data temp0.current
execute if data storage svm:data temp0.list[0] run function svm:check_loop
